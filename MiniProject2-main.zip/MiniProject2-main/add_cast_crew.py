#import importlib  
#load = importlib.import_module("load-json")
from pickle import APPEND
from pymongo import MongoClient

client = MongoClient("mongodb://localhost:27017")
# Create or open database on server.
db = client["291db"]
title_collection = db["title_basics"]
name_collection = db["name_basics"]

cast_id = input("Provide cast/crew member id: ")
title_id = input("Provide title id: ")
category_inpt = input("Provide category: ")

titles = db.title_collection.find( { tconst: {$in[title_id]} } )
titles_2 = []
for title in titles:
    titles_2.append(title["tconst"])
names = db.name_collection.find( { nconst: {$in[cast_id]} } )
names_2 = []
for name in names:
    names_2.append(name["nconst"])

if title_id in titles_2:
    if cast_id in names_2:
        roles_collection = db["title_principals"]
        ordering_insrt = db.roles_collection.find( { category: category_inpt }).sort({ordering:-1}).limit(1)["ordering"] + 1
        db.roles_collection.insert({tconst: title_id, ordering: ordering_insrt, nconst: cast_id, category: category_inpt, job: "/N", characters: "/N"})
    else:
        print("Icorrect cast id")
else:
    print("Incorrect title id")