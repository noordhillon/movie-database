from pymongo import MongoClient

client = MongoClient()
db = client["291db"]
title_basics = db["title_basics"]


def add_movie():
    movie_id = input("Enter a unique movie ID: ")
    movie_title = input("Enter the title of the movie to be added: ")
    movie_year = input("Enter the start year of the movie: ")
    movie_running_time = input("Enter the running time of the movie: ")
    movie_genres = []
    no_of_genres = int(input("Enter how many genres are there for this film: "))
    i = 1
    while i <= no_of_genres:
        genre = input("Enter the genre: ")
        movie_genres.append(genre)
        i += 1

    added_movie = [
        {
            "tconst": movie_id,
            "titleType": "movie",
            "primaryTitle": movie_title,
            "originalTitle": movie_title,
            "isAdult": "\\N",
            "startYear": movie_year,
            "endYear": "\\N",
            "runtimeMinutes": movie_running_time,
            "genres": movie_genres
        }
    ]
    title_basics.insert_one(added_movie[0])
    return True


def main():
    if add_movie():
        print("The movie has been successfully added!")
    else:
        print("The movie has not been added")











