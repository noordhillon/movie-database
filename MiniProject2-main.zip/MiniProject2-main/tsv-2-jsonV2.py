import json


def tsvjsonconverter(input_file, output_file):
    finalArr = []
    file = open(input_file, 'r', encoding='utf-8')
    a = file.readline()

    titles = [t.strip() for t in a.split('\t')]
    for line in file:
        d = {}
        for t, f in zip(titles, line.split('\t')):
            if (t == 'primaryProfession' or t == 'knownForTitles' or t == 'genres' or t == 'characters'):
                d[t] = list(f.split(','))
                d[t][len(d[t])-1] = d[t][len(d[t])-1].rstrip("\n")
            elif t == 'numVotes':
                d[t] = int(f.strip())
            else:
                d[t] = f.strip()

        finalArr.append(d)

    with open(output_file, 'w', encoding='utf-8') as output_file:
        output_file.write(json.dumps(finalArr, indent=4))


def convert_first():
    input_filename = 'name.basics.tsv'
    output_filename = 'name.basics.json'
    tsvjsonconverter(input_filename, output_filename)


def convert_second():
    input_filename = 'title.basics.tsv'
    output_filename = 'title.basics.json'
    tsvjsonconverter(input_filename, output_filename)


def convert_third():
    input_filename = 'title.principals.tsv'
    output_filename = 'title.principals.json'
    tsvjsonconverter(input_filename, output_filename)


def convert_fourth():
    input_filename = 'title.ratings.tsv'
    output_filename = 'title.ratings.json'
    tsvjsonconverter(input_filename, output_filename)


def main():
    convert_first()
    convert_second()
    convert_third()
    convert_fourth()

main()


