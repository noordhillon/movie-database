#import importlib
#load = importlib.import_module("load-json")
from pymongo import MongoClient


def add_cast():
    client = MongoClient("mongodb://localhost:27017")
    # Create or open database on server.
    db = client["291db"]
    title_collection = db["title_basics"]
    name_collection = db["name_basics"]

    cast_id = input("Provide cast/crew member id: ")
    title_id = input("Provide title id: ")
    category_inpt = input("Provide category: ")

    # titles = db.title_collection.find_one({"tconst": {"$in": [title_id]}})
    titles = title_collection.find_one({"tconst": title_id})
    if titles == None:
        print("No such title has been found in the database.")
        return

    names = name_collection.find_one({"nconst": cast_id})
    if names == None:
        print("No such name has been found in the database.")
        return

    roles_collection = db["title_principals"]
    ordering_insrt = roles_collection.find({"category": category_inpt}).sort({"ordering":-1}).limit(1)["ordering"]
    print(type(ordering_insrt))
    roles_collection.insert({"tconst": title_id, "ordering": ordering_insrt, "nconst": cast_id, "category": category_inpt, "job": "/N", "characters": "/N"})

add_cast()
