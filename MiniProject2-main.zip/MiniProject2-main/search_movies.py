#import importlib  
#load = importlib.import_module("load-json")
from pymongo import MongoClient

client = MongoClient("mongodb://localhost:27017")
# Create or open database on server.
db = client["291db"]

keyword = input("Search for keyword: ")
title_collection = db["title_basics"]
ratings_collection = db["title_ratings"]
seacrh_results = []
i = 0
for title in db.title_collection.find( { $or: [{primaryTitle: { $regex: keyword, $options: "i" }}, {startYear: { $regex: keyword, $options: "i" }}]}):
    print(i, title["primaryTitle"])
    seacrh_results.append(title)
    i += 1

selection_1 = int(input("Select a movie using index: "))
selection_2 = input("Select a function: /n 1.Rating /n 2. Number of votes /n 3. Names of cast/crew")
title_code = seacrh_results[selection_1]["tconst"]
if selection_2 == 1:
    movie_stats = db.ratings_collection.find( { tconst: title_code})
    print("Rating:", movie_stats["averageRating"])
elif selection_2 == 2:
    movie_stats = db.ratings_collection.find( { tconst: title_code})
    print("Rating:", movie_stats["numVotes"])
elif selection_2 == 3:
    roles_collection = db["title_principals"]
    name_collection = db["name_basics"]
    crew_list = []
    for crew in db.roles_collection.find( { tconst: title_code}):
        character = crew["characters"]
        crew = db.find( { nconst: crew["nconst"]})
        name = crew["primaryName"]
        print("Name:", name, " | ", "Character:", character)
    

