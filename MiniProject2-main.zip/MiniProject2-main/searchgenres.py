#import importlib  
#load = importlib.import_module("load-json")
from pymongo import MongoClient

client = MongoClient("mongodb://localhost:27017")
# Create or open database on server.
db = client["291db"]

movies_collection = db["title_basics"]
ratings_collection = db["title_ratings"]
#movies_collection.createIndex({"tconst": 1})
genre_input = input("Provide a genre: ")
vote_input = input("Provide a minimum vote count: ")
#titles_genre =  movies_collection.find({"genres": genre_input}, {"primaryTitle": 1, "genres": 1})
#titles_genre =  movies_collection.find({"genres": genre_input})
#titles_votes = ratings_collection.find({"numVotes": {"$gte": vote_input} })
#for title in titles_genre:
 #   print(title)
vote_input = int(vote_input)



'''result = movies_collection.aggregate([
    {"$lookup": {"from": "title_ratings", "localField": "tconst", "foreignField": "tconst", "as": "movie_rating"}},
     {"$match": {"$and": [{"genres": genre_input}, {"numVotes": {"$gte": vote_input}}]}},
    {"$match": {"genres": genre_input}},
    {"$project": {"primaryTitle": 1, "numVotes": 1}}
    ])
for test in result:
    print(test)'''

#print(db.list_collection_names())

#titles_genre =  movies_collection.find({})

#results = movies_collection.find({})
#for rental in results:
 #   print(rental)

name_collection = db["name_basics"]
user_input = input("Enter cast/crew member name: ")
profession_result = name_collection.find({"primaryName": user_input}, {"_id": 0, "primaryProfession": 1})
print("Person's professions:")
for profession in profession_result:
    print(profession)
cast_id = name_collection.find_one({"primaryName": {"$regex": user_input, "$options": 'i'}}, {"_id": 0, "nconst": 1})
cast_id = cast_id["nconst"]
title_principals_collection = db["title_principals"]
for worked_on in title_principals_collection.find({{"nconst": cast_id}, {"_id": 0}}):
    if worked_on["job"] != "\n":
        movie_worked_on = movies_collection.find({"nconst": cast_id}, {"_id": 0})
        print("Job: ", worked_on["job"], "Characters: ", worked_on["characters"])
   # for item in title_list["knownForTitles"]:
     #   movie_title = movies_collection.find_one({"tconst": item}, {"_id": 0, "primaryTitle": 1})
      #  movie_title = movie_title["primaryTitle"]
      #  print(movie_title)

    #{"$match": {"genres": genre_input}},
    #{"$project": {"primaryTitle": 1, "numVotes": 1}}
    #])
