from pymongo import MongoClient
client = MongoClient("mongodb://localhost:27017")
db = client["291db"]

movies_collection = db["title_basics"]
ratings_collection = db["title_ratings"]
name_collection = db["name_basics"]
ratings_collection.create_index([("tconst", 1)]) 

def main_menu():
    user_input = 1
    #while user_input == 1 or user_input == 2 or user_input == 3 or user_input == 4 or user_input == 5 or user_input == 6:
    while user_input != 6:
        print("*" * 22)
        print("Main Menu")
        print("1. Search for titles")
        print("2. Search for genres")
        print("3. Search for cast/crew members")
        print("4. Add a movie")
        print("5. Add a cast/crew member")
        print("6. End program")
        user_input = input("Select an option: ")
        user_input = int(user_input)
        if user_input == 2:
            searchgenres()
        elif user_input == 3:
            searchcast()
        elif user_input == 6:
            print("Goodbye!")
        else:
            print("\nIncorrect. Please re-enter.")

def searchgenres():
    genre_input = input("Provide a genre: ")
    vote_input = input("Provide a minimum vote count: ")
    vote_input = int(vote_input)

    pipeline = [
        {"$lookup": {"from": "title_ratings", 
                "localField": "tconst", 
                "foreignField": "tconst", 
                "as": "movie_rate"}},
                {"$match": {"$and": [{"genres": {"$regex": genre_input, "$options": 'i'}}, {"movie_rate.numVotes": {"$gte": vote_input}}]}},
                {"$sort": {"movie_rate.averageRating": -1}}
                ]
    result = movies_collection.aggregate(pipeline)
    for item in result:
        print(item["primaryTitle"])

def searchcast():
    user_input = input("Enter cast/crew member name: ")
    profession_result = name_collection.find({"primaryName": user_input}, {"_id": 0, "primaryProfession": 1})
    print("Person's professions:")
    for profession in profession_result:
        print(profession)
    cast_id = name_collection.find_one({"primaryName": {"$regex": user_input, "$options": 'i'}}, {"_id": 0, "nconst": 1})
    cast_id = cast_id["nconst"]
    title_principals_collection = db["title_principals"]
    for worked_on in title_principals_collection.find({"$and": [{"nconst": cast_id}, {"$or": [{"job": {"$ne": "\\N"}}, {"characters": {"$ne": "\\N"}}]}]}):
        worked_on_id = worked_on["tconst"]
        movie_worked_on = movies_collection.find_one({"tconst": worked_on_id})
        print("-"*20)
        print("Title", movie_worked_on["primaryTitle"])
        if (worked_on["job"] != "\\N"):
            print("Job: ", worked_on["job"])
        elif (worked_on["job"] == "\\N"):
            print("No jobs")
        if (worked_on["characters"][0] != "\\N"):
            print("Characters: ", worked_on["characters"])
        elif (worked_on["characters"][0] == "\\N"):
            print("No characters")

def main():
    main_menu()

main()
