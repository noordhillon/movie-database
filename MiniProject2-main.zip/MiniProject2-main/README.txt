Names: Roopdilawar Singh; Harnoor Singh; Neeraj Narayanan
CCID's: roopdila; hsingh1; nnarayan

Collaboration Statement:
People we collaborated with: N/A
This is to state that our group did not collaborate with anyone. 

References: N/A
This is to state that our group did not use any source of information besides the course
textbook and class notes.